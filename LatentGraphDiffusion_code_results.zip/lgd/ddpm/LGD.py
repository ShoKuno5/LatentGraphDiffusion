import copy

import torch
import torch.nn as nn
import numpy as np
import pytorch_lightning as pl
from torch.optim.lr_scheduler import LambdaLR
from einops import rearrange, repeat
from contextlib import contextmanager
from functools import partial
from tqdm import tqdm
from torchvision.utils import make_grid
# from pytorch_lightning.utilities.distributed import rank_zero_only
from torch_geometric.graphgym.config import cfg
import logging
from torch_geometric.graphgym.loss import compute_loss
import networkx as nx


# TODO: need further debug; the following utils is not completed
# from lgd.model.utils import log_txt_as_img, exists, default, ismap, isimage, mean_flat, count_params, instantiate_from_config
from lgd.ddpm.ema import LitEma
from lgd.ddpm.distributions import normal_kl, DiagonalGaussianDistribution
# from ldm.models.autoencoder import VQModelInterface, IdentityFirstStage, AutoencoderKL
from lgd.model.utils import make_beta_schedule, extract_into_tensor, extract_into_sparse_tensor, noise_like, num2batch, \
    exists, default, ismap, mean_flat, count_params, instantiate_from_config, symmetrize
from lgd.ddpm.ddim import DDIMSampler
from lgd.model.Dictionary import *
from lgd.model.GraphTransformerEncoder import *
from lgd.model.SyntheticGraphTransformerEncoder import *
from lgd.model.DenoisingTransformer import DenoisingTransformer


def disabled_train(self, mode=True):
    """Overwrite model.train with this function to make sure train/eval mode
    does not change anymore."""
    return self


def uniform_on_device(r1, r2, shape, device):
    return (r1 - r2) * torch.rand(*shape, device=device) + r2


class DDPM(pl.LightningModule):
    # classic DDPM with Gaussian diffusion, in image space
    def __init__(self,
                 gt_config=None,
                 timesteps=1000,
                 beta_schedule="linear",
                 loss_type="l2",
                 ckpt_path=None,
                 ignore_keys=[],
                 load_only_unet=False,
                 monitor="val/loss",
                 use_ema=False,   # originally True
                 first_stage_key=None,  # TODO: need to change this?
                 image_size=256,
                 hid_dim=3,
                 log_every_t=100,
                 clip_denoised=False,  # originally True
                 linear_start=1e-4,
                 linear_end=2e-2,
                 cosine_s=8e-3,
                 given_betas=None,
                 original_elbo_weight=0.,
                 v_posterior=0.,  # weight for choosing posterior variance as sigma = (1-v) * beta_tilde + v * beta
                 l_simple_weight=1.,
                 conditioning_key=None,
                 parameterization="x0",  # all assuming fixed variance schedules
                 scheduler_config=None,
                 use_positional_encodings=False,
                 learn_logvar=False,
                 logvar_init=0.,
                 ):
        super().__init__()
        assert parameterization in ["eps", "x0"], 'currently only supporting "eps" and "x0"'
        self.parameterization = parameterization  # TODO: now we only support "x0", i.e. output graph without noise
        print(f"{self.__class__.__name__}: Running in {self.parameterization}-prediction mode")
        self.cond_stage_model = None
        self.clip_denoised = clip_denoised
        self.log_every_t = log_every_t
        self.first_stage_key = first_stage_key
        self.image_size = image_size  # try conv?
        self.hid_dim = hid_dim
        self.force_undirected = cfg.diffusion.get('force_undirected', False)
        self.use_positional_encodings = use_positional_encodings
        self.model = DiffusionWrapper(gt_config, conditioning_key)
        count_params(self.model, verbose=True)
        self.use_ema = use_ema
        if self.use_ema:
            self.model_ema = LitEma(self.model)
            print(f"Keeping EMAs of {len(list(self.model_ema.buffers()))}.")

        self.use_scheduler = scheduler_config is not None
        if self.use_scheduler:
            self.scheduler_config = scheduler_config

        self.v_posterior = v_posterior
        self.original_elbo_weight = original_elbo_weight
        self.l_simple_weight = l_simple_weight

        if monitor is not None:
            self.monitor = monitor
        if ckpt_path is not None:
            self.init_from_ckpt(ckpt_path, ignore_keys=ignore_keys, only_model=load_only_unet)

        self.register_schedule(given_betas=given_betas, beta_schedule=beta_schedule, timesteps=timesteps,
                               linear_start=linear_start, linear_end=linear_end, cosine_s=cosine_s)

        self.loss_type = loss_type

        self.learn_logvar = learn_logvar
        self.logvar = torch.full(fill_value=logvar_init, size=(self.num_timesteps,))
        # if self.learn_logvar:
        self.logvar = nn.Parameter(self.logvar, requires_grad=self.learn_logvar)


    def register_schedule(self, given_betas=None, beta_schedule="linear", timesteps=1000,
                          linear_start=1e-4, linear_end=2e-2, cosine_s=8e-3):
        if exists(given_betas):
            betas = given_betas
        else:
            betas = make_beta_schedule(beta_schedule, timesteps, linear_start=linear_start, linear_end=linear_end,
                                       cosine_s=cosine_s)
        alphas = 1. - betas
        alphas_cumprod = np.cumprod(alphas, axis=0)
        alphas_cumprod_prev = np.append(1., alphas_cumprod[:-1])

        timesteps, = betas.shape
        self.num_timesteps = int(timesteps)
        self.linear_start = linear_start
        self.linear_end = linear_end
        assert alphas_cumprod.shape[0] == self.num_timesteps, 'alphas have to be defined for each timestep'

        to_torch = partial(torch.tensor, dtype=torch.float32)

        self.register_buffer('betas', to_torch(betas))
        self.register_buffer('alphas_cumprod', to_torch(alphas_cumprod))
        self.register_buffer('alphas_cumprod_prev', to_torch(alphas_cumprod_prev))

        # calculations for diffusion q(x_t | x_{t-1}) and others
        self.register_buffer('sqrt_alphas_cumprod', to_torch(np.sqrt(alphas_cumprod)))
        self.register_buffer('sqrt_one_minus_alphas_cumprod', to_torch(np.sqrt(1. - alphas_cumprod)))
        self.register_buffer('log_one_minus_alphas_cumprod', to_torch(np.log(1. - alphas_cumprod)))
        self.register_buffer('sqrt_recip_alphas_cumprod', to_torch(np.sqrt(1. / alphas_cumprod)))
        self.register_buffer('sqrt_recipm1_alphas_cumprod', to_torch(np.sqrt(1. / alphas_cumprod - 1)))

        # calculations for posterior q(x_{t-1} | x_t, x_0)
        posterior_variance = (1 - self.v_posterior) * betas * (1. - alphas_cumprod_prev) / (
                    1. - alphas_cumprod) + self.v_posterior * betas
        # above: equal to 1. / (1. / (1. - alpha_cumprod_tm1) + alpha_t / beta_t)
        self.register_buffer('posterior_variance', to_torch(posterior_variance))
        # below: log calculation clipped because the posterior variance is 0 at the beginning of the diffusion chain
        self.register_buffer('posterior_log_variance_clipped', to_torch(np.log(np.maximum(posterior_variance, 1e-20))))
        self.register_buffer('posterior_mean_coef1', to_torch(
            betas * np.sqrt(alphas_cumprod_prev) / (1. - alphas_cumprod)))
        self.register_buffer('posterior_mean_coef2', to_torch(
            (1. - alphas_cumprod_prev) * np.sqrt(alphas) / (1. - alphas_cumprod)))

        if self.parameterization == "eps":
            lvlb_weights = self.betas ** 2 / (
                        2 * self.posterior_variance * to_torch(alphas) * (1 - self.alphas_cumprod))
        elif self.parameterization == "x0":
            lvlb_weights = 0.5 * np.sqrt(torch.Tensor(alphas_cumprod)) / (2. * 1 - torch.Tensor(alphas_cumprod))
        else:
            raise NotImplementedError("mu not supported")
        # TODO how to choose this term
        lvlb_weights[0] = lvlb_weights[1]
        self.register_buffer('lvlb_weights', lvlb_weights, persistent=False)
        assert not torch.isnan(self.lvlb_weights).all()

    @contextmanager
    def ema_scope(self, context=None):
        if self.use_ema:
            self.model_ema.store(self.model.parameters())
            self.model_ema.copy_to(self.model)
            if context is not None:
                print(f"{context}: Switched to EMA weights")
        try:
            yield None
        finally:
            if self.use_ema:
                self.model_ema.restore(self.model.parameters())
                if context is not None:
                    print(f"{context}: Restored training weights")

    def init_from_ckpt(self, path, ignore_keys=list(), only_model=False):
        sd = torch.load(path, map_location="cpu")
        if "state_dict" in list(sd.keys()):
            sd = sd["state_dict"]
        keys = list(sd.keys())
        for k in keys:
            for ik in ignore_keys:
                if k.startswith(ik):
                    print("Deleting key {} from state_dict.".format(k))
                    del sd[k]
        missing, unexpected = self.load_state_dict(sd, strict=False) if not only_model else self.model.load_state_dict(
            sd, strict=False)
        print(f"Restored from {path} with {len(missing)} missing and {len(unexpected)} unexpected keys")
        if len(missing) > 0:
            print(f"Missing Keys: {missing}")
        if len(unexpected) > 0:
            print(f"Unexpected Keys: {unexpected}")

    def q_mean_variance(self, x_start, t, batch_idx):
        """
        Get the distribution q(x_t | x_0).
        :param x_start: the [N x C x ...] tensor of noiseless inputs.
        :param t: the number of diffusion steps (minus 1). Here, 0 means one step.
        :return: A tuple (mean, variance, log_variance), all of x_start's shape.
        """
        mean = (extract_into_sparse_tensor(self.sqrt_alphas_cumprod, t, batch_idx) * x_start)
        variance = extract_into_sparse_tensor(1.0 - self.alphas_cumprod, t, batch_idx)
        log_variance = extract_into_sparse_tensor(self.log_one_minus_alphas_cumprod, t, batch_idx)
        return mean, variance, log_variance

    def predict_start_from_noise(self, x_t, t, noise, batch_idx):
        return (
                extract_into_sparse_tensor(self.sqrt_recip_alphas_cumprod, t, batch_idx) * x_t -
                extract_into_sparse_tensor(self.sqrt_recipm1_alphas_cumprod, t, batch_idx) * noise
        )

    def q_posterior(self, x_start, x_t, t, batch_idx):
        posterior_mean = (
                extract_into_sparse_tensor(self.posterior_mean_coef1, t, batch_idx) * x_start +
                extract_into_sparse_tensor(self.posterior_mean_coef2, t, batch_idx) * x_t
        )
        posterior_variance = extract_into_sparse_tensor(self.posterior_variance, t, batch_idx)
        posterior_log_variance_clipped = extract_into_sparse_tensor(self.posterior_log_variance_clipped, t, batch_idx)
        return posterior_mean, posterior_variance, posterior_log_variance_clipped

    def p_mean_variance(self, x, t, batch_idx, clip_denoised: bool):
        model_out = self.model(x, t)
        if self.parameterization == "eps":
            x_recon = self.predict_start_from_noise(x, t=t, noise=model_out, batch_idx=batch_idx)
        elif self.parameterization == "x0":
            x_recon = model_out
        if clip_denoised:
            x_recon.clamp_(-1., 1.)

        model_mean, posterior_variance, posterior_log_variance = self.q_posterior(x_start=x_recon, x_t=x, t=t, batch_idx=batch_idx)
        return model_mean, posterior_variance, posterior_log_variance

    @torch.no_grad()
    def p_sample(self, x, t, batch_idx, clip_denoised=True, repeat_noise=False):
        b, *_, device = *x.shape, x.device
        model_mean, _, model_log_variance = self.p_mean_variance(x=x, t=t, clip_denoised=clip_denoised, batch_idx=batch_idx)
        noise = noise_like(x.shape, device, repeat_noise)
        # no noise when t == 0
        nonzero_mask = (1 - (t == 0).float()).reshape(b, *((1,) * (len(x.shape) - 1)))
        return model_mean + nonzero_mask * (0.5 * model_log_variance).exp() * noise

    @torch.no_grad()
    def p_sample_loop(self, shape, batch_idx, return_intermediates=False):
        device = self.betas.device
        b = int(torch.max(batch_idx)) + 1
        img = torch.randn(shape, device=device)
        intermediates = [img]
        for i in tqdm(reversed(range(0, self.num_timesteps)), desc='Sampling t', total=self.num_timesteps):
            img = self.p_sample(img, torch.full((b,), i, device=device, dtype=torch.long), batch_idx=batch_idx,
                                clip_denoised=self.clip_denoised)
            if i % self.log_every_t == 0 or i == self.num_timesteps - 1:
                intermediates.append(img)
        if return_intermediates:
            return img, intermediates
        return img

    @torch.no_grad()
    def sample(self, batch_idx, batch_size=16, return_intermediates=False):
        hid_dim = self.hid_dim
        return self.p_sample_loop((batch_idx.shape[0], hid_dim), batch_idx=batch_idx,
                                  return_intermediates=return_intermediates)

    def q_sample(self, x_start, t, batch_idx=None, noise=None):
        noise = default(noise, lambda: torch.randn_like(x_start))
        if (t >= self.num_timesteps).any():
            return noise
        if batch_idx is None:
            return (extract_into_tensor(self.sqrt_alphas_cumprod, t, x_start.shape) * x_start +
                extract_into_tensor(self.sqrt_one_minus_alphas_cumprod, t, x_start.shape) * noise)
        else:
            return (extract_into_sparse_tensor(self.sqrt_alphas_cumprod, t, batch_idx) * x_start +
                extract_into_sparse_tensor(self.sqrt_one_minus_alphas_cumprod, t, batch_idx) * noise)

    def get_loss(self, pred, target, mean=True):
        if self.loss_type == 'l1':
            loss = (target - pred).abs()
            if mean:
                loss = loss.mean()
        elif self.loss_type == 'l2':
            if mean:
                loss = torch.nn.functional.mse_loss(target, pred)
            else:
                loss = torch.nn.functional.mse_loss(target, pred, reduction='none')
        else:
            raise NotImplementedError("unknown loss type '{loss_type}'")

        return loss

    def p_losses(self, batch, t, noise=None, task_id=None):
        batch_idx = batch.batch_idx
        x_start = torch.cat([batch.x, batch.edge_attr], dim=0)
        # TODO: this class does not support conditional generation and masked graph,
        #  so x_start should not be masked
        noise = default(noise, lambda: torch.randn_like(x_start))
        x_noisy = self.q_sample(x_start=x_start, t=t, batch_idx=batch_idx, noise=noise)
        batch.x = x_noisy[:batch.num_nodes]
        batch.edge_attr = x_noisy[batch.num_nodes:]
        model_out = self.model(batch, t, task_id)

        loss_dict = {}
        if self.parameterization == "eps":
            target = noise
        elif self.parameterization == "x0":
            target = x_start
        else:
            raise NotImplementedError(f"Paramterization {self.parameterization} not yet supported")

        loss = self.get_loss(model_out, target, mean=False).mean(dim=[1, 2, 3])

        log_prefix = 'train' if self.training else 'val'

        loss_dict.update({f'{log_prefix}/loss_simple': loss.mean()})
        loss_simple = loss.mean() * self.l_simple_weight

        loss_vlb = (self.lvlb_weights[t] * loss).mean()
        loss_dict.update({f'{log_prefix}/loss_vlb': loss_vlb})

        loss = loss_simple + self.original_elbo_weight * loss_vlb

        loss_dict.update({f'{log_prefix}/loss': loss})

        return loss, loss_dict

    def forward(self, batch, task_id=None, *args, **kwargs):
        # b, c, h, w, device, img_size, = *x.shape, x.device, self.image_size
        # assert h == img_size and w == img_size, f'height and width of image must be {img_size}'
        t = torch.randint(0, self.num_timesteps, (batch.num_graphs,), device=self.device).long()
        return self.p_losses(batch, t, task_id=task_id, *args, **kwargs)

    # def get_input(self, batch, k):
    #     x = batch[k]
    #     if len(x.shape) == 3:
    #         x = x[..., None]
    #     x = rearrange(x, 'b h w c -> b c h w')
    #     x = x.to(memory_format=torch.contiguous_format).float()
    #     return x

    def get_input(self, batch):
        num_node = batch.num_node_per_graph
        batch_idx = torch.cat([batch.batch, num2batch(num_node ** 2)], dim=0)
        batch.batch_idx = batch_idx
        batch.batch_size = batch.num_graphs
        return batch

    def shared_step(self, batch, task_id=None):
        # x = self.get_input(batch, self.first_stage_key)
        batch = self.get_input(batch)
        if task_id is not None:
            batch.task_id = task_id
        loss, loss_dict = self(batch, task_id)
        return loss, loss_dict

    def training_step(self, batch, task_id=None):
        loss, loss_dict = self.shared_step(batch, task_id)

        self.log_dict(loss_dict, prog_bar=True,
                      logger=True, on_step=True, on_epoch=True)

        self.log("global_step", self.global_step,
                 prog_bar=True, logger=True, on_step=True, on_epoch=False)

        if self.use_scheduler:
            lr = self.optimizers().param_groups[0]['lr']
            self.log('lr_abs', lr, prog_bar=True, logger=True, on_step=True, on_epoch=False)

        return loss

    @torch.no_grad()
    def validation_step(self, batch, task_id=None):
        _, loss_dict_no_ema = self.shared_step(batch, task_id)
        with self.ema_scope():
            _, loss_dict_ema = self.shared_step(batch, task_id)
            loss_dict_ema = {key + '_ema': loss_dict_ema[key] for key in loss_dict_ema}
        self.log_dict(loss_dict_no_ema, prog_bar=False, logger=True, on_step=False, on_epoch=True)
        self.log_dict(loss_dict_ema, prog_bar=False, logger=True, on_step=False, on_epoch=True)

    def on_train_batch_end(self, *args, **kwargs):
        if self.use_ema:
            self.model_ema(self.model)

    def _get_rows_from_list(self, samples):
        n_imgs_per_row = len(samples)
        denoise_grid = rearrange(samples, 'n b c h w -> b n c h w')
        denoise_grid = rearrange(denoise_grid, 'b n c h w -> (b n) c h w')
        denoise_grid = make_grid(denoise_grid, nrow=n_imgs_per_row)
        return denoise_grid

    @torch.no_grad()
    def log_images(self, batch, N=8, n_row=2, sample=True, return_keys=None, **kwargs):
        log = dict()
        # x = self.get_input(batch, self.first_stage_key)
        batch = self.get_input(batch)
        x = torch.cat([batch.x, batch.edge_attr], dim=0)
        N = min(batch.num_node_per_graph.shape[0], N)
        n_row = min(batch.num_node_per_graph.shape[0], n_row)
        x = x.to(self.device)[:N]  # TODO: update this index selection to graph data
        log["inputs"] = x

        # get diffusion row
        diffusion_row = list()
        x_start = x[:n_row]  # TODO: update the img size to graph size

        num_node = batch.num_node_per_graph[:n_row]
        batch_idx = torch.cat([batch.batch, num2batch(num_node ** 2)], dim=0)

        for t in range(self.num_timesteps):
            if t % self.log_every_t == 0 or t == self.num_timesteps - 1:
                t = repeat(torch.tensor([t]), '1 -> b', b=n_row)
                t = t.to(self.device).long()
                noise = torch.randn_like(x_start)
                x_noisy = self.q_sample(x_start=x_start, t=t, noise=noise, batch_idx=batch_idx)
                diffusion_row.append(x_noisy)

        log["diffusion_row"] = self._get_rows_from_list(diffusion_row)

        if sample:
            # get denoise row
            with self.ema_scope("Plotting"):
                samples, denoise_row = self.sample(batch_idx, batch_size=N, return_intermediates=True)

            log["samples"] = samples
            log["denoise_row"] = self._get_rows_from_list(denoise_row)

        if return_keys:
            if np.intersect1d(list(log.keys()), return_keys).shape[0] == 0:
                return log
            else:
                return {key: log[key] for key in return_keys}
        return log

    def configure_optimizers(self):
        lr = self.learning_rate
        params = list(self.model.parameters())
        if self.learn_logvar:
            params = params + [self.logvar]
        opt = torch.optim.AdamW(params, lr=lr)
        return opt


class LatentDiffusion(DDPM):
    """main class"""
    def __init__(self,
                 first_stage_config,  # actually the ckpt path
                 cond_stage_config,
                 num_timesteps_cond=None,
                 cond_stage_key="unconditional",
                 first_stage_trainable=False,
                 cond_stage_trainable=False,
                 concat_mode=False,  # default change to cross attention
                 cond_stage_forward=None,
                 conditioning_key=None,
                 scale_factor=1.0,
                 node_factor=1.0,
                 edge_factor=1.0,
                 recon_factor=0.0,
                 graph_factor=1.0,
                 scale_by_std=False,
                 train_mode='sample',
                 *args, **kwargs):
        self.num_timesteps_cond = default(num_timesteps_cond, 1)
        self.scale_by_std = scale_by_std
        # assert self.num_timesteps_cond <= kwargs['timesteps']
        # for backwards compatibility after implementation of DiffusionWrapper
        # assert cond_stage_config in cond_stage_config_list
        assert cond_stage_key in cond_stage_key_list
        if conditioning_key is None:
            conditioning_key = 'concat' if concat_mode else 'crossattn'
        assert conditioning_key in conditioning_key_list
        self.cond_stage_key = cond_stage_key
        if self.cond_stage_key in ['masked_graph', 'prompt_graph', 'pe']:
            cond_stage_config = "__is_first_stage__"  # TODO: better to do this
        if cond_stage_config == '__is_unconditional__':
            conditioning_key = None
        ckpt_path = kwargs.pop("ckpt_path", None)
        ignore_keys = kwargs.pop("ignore_keys", [])
        super().__init__(conditioning_key=conditioning_key, *args, **kwargs)
        self.concat_mode = concat_mode
        self.first_stage_trainable = first_stage_trainable
        self.cond_stage_trainable = cond_stage_trainable
        try:
            self.num_downs = len(first_stage_config.params.ddconfig.ch_mult) - 1
        except:
            self.num_downs = 0
        if not scale_by_std:
            self.scale_factor = scale_factor
        else:
            self.register_buffer('scale_factor', torch.tensor(scale_factor))
        self.instantiate_first_stage(first_stage_config)
        self.instantiate_cond_stage(cond_stage_config)
        self.cond_stage_forward = cond_stage_forward
        self.clip_denoised = False
        self.bbox_tokenizer = None
        self.node_factor = cfg.diffusion.get("node_factor", node_factor)
        self.edge_factor = cfg.diffusion.get("edge_factor", edge_factor)
        self.graph_factor = cfg.diffusion.get("graph_factor", graph_factor)
        self.recon_factor = cfg.diffusion.get("recon_factor", recon_factor)
        assert train_mode in ['sample', 'half-sample', 'complete-noise']
        self.train_mode = train_mode

        self.restarted_from_ckpt = False
        if ckpt_path is not None:
            self.init_from_ckpt(ckpt_path, ignore_keys)
            self.restarted_from_ckpt = True

    def make_cond_schedule(self, ):
        self.cond_ids = torch.full(size=(self.num_timesteps,), fill_value=self.num_timesteps - 1, dtype=torch.long)
        ids = torch.round(torch.linspace(0, self.num_timesteps - 1, self.num_timesteps_cond)).long()
        self.cond_ids[:self.num_timesteps_cond] = ids

    # @rank_zero_only
    @torch.no_grad()
    def on_train_batch_start(self, batch, batch_idx, dataloader_idx):
        # only for very first batch
        if self.scale_by_std and self.current_epoch == 0 and self.global_step == 0 and batch_idx == 0 and not self.restarted_from_ckpt:
            assert self.scale_factor == 1., 'rather not use custom rescaling and std-rescaling simultaneously'
            # set rescale weight to 1./std of encodings
            print("### USING STD-RESCALING ###")
            batch = super().get_input(batch)  # TODO: check this
            batch = batch.to(self.device)
            encoder_posterior = self.encode_first_stage(batch)  # TODO: implement encoder
            z = self.get_first_stage_encoding(encoder_posterior).detach()
            del self.scale_factor
            self.register_buffer('scale_factor', 1. / z.flatten().std())
            print(f"setting self.scale_factor to {self.scale_factor}")
            print("### USING STD-RESCALING ###")

    def register_schedule(self,
                          given_betas=None, beta_schedule="linear", timesteps=1000,
                          linear_start=1e-4, linear_end=2e-2, cosine_s=8e-3):
        super().register_schedule(given_betas, beta_schedule, timesteps, linear_start, linear_end, cosine_s)

        self.shorten_cond_schedule = self.num_timesteps_cond > 1
        if self.shorten_cond_schedule:
            self.make_cond_schedule()

    def instantiate_first_stage(self, config):
        model = eval(cfg.encoder.get("model_type", "GraphTransformerEncoder"))(cfg=cfg.encoder)
        self.first_stage_model = model
        sd = torch.load(config, map_location="cpu")
        if "state_dict" in list(sd.keys()):
            sd = sd["state_dict"]
        if "model_state" in list(sd.keys()):
            sd = sd["model_state"]

        state_dict = {}
        for k, v in sd.items():
            # new_k = k.replace('model.', '') if 'model' in k else k
            new_k = k[6:] if k.startswith('model.') else k
            state_dict[new_k] = v
        missing, unexpected = self.first_stage_model.load_state_dict(state_dict, strict=False)
        logging.info(f"Restored from {config} with {len(missing)} missing and {len(unexpected)} unexpected keys")
        if len(missing) > 0:
            logging.info(f"Missing Keys: {missing}")
        if len(unexpected) > 0:
            logging.info(f"Unexpected Keys: {unexpected}")
        if not self.first_stage_trainable:
            self.first_stage_model = model.eval()
            self.first_stage_model.train = disabled_train
            for param in self.first_stage_model.parameters():
                param.requires_grad = False

        # model = instantiate_from_config(config)
        # if not self.first_stage_trainable:
        #     self.first_stage_model = model.eval()
        #     self.first_stage_model.train = disabled_train
        #     for param in self.first_stage_model.parameters():
        #         param.requires_grad = False
        # else:
        #     self.first_stage_model = model

    def instantiate_cond_stage(self, config):
        if config == "__is_first_stage__":
            print("Using first stage also as cond stage.")
            self.cond_stage_model = self.first_stage_model
        elif config == "__is_unconditional__":
            print(f"Training {self.__class__.__name__} as an unconditional model.")
            self.cond_stage_model = None
            # self.be_unconditional = True
        else:
            # TODO: for other conditions, e.g. multi-model and label, specialize the cond_stage_model
            # model = instantiate_from_config(config)
            model = eval(cfg.cond.get("model_type", "GraphTransformerEncoder"))(cfg=cfg.cond)
            self.cond_stage_model = model
            sd = torch.load(config, map_location="cpu")
            if "state_dict" in list(sd.keys()):
                sd = sd["state_dict"]
            if "model_state" in list(sd.keys()):
                sd = sd["model_state"]

            state_dict = {}
            for k, v in sd.items():
                new_k = k.replace('model.', '') if 'model' in k else k
                state_dict[new_k] = v
            missing, unexpected = self.first_stage_model.load_state_dict(state_dict, strict=False)
            # keys = list(sd.keys())
            # missing, unexpected = self.cond_stage_model.load_state_dict(sd, strict=False)
            print(f"Restored from {config} with {len(missing)} missing and {len(unexpected)} unexpected keys")
            if len(missing) > 0:
                print(f"Missing Keys: {missing}")
            if len(unexpected) > 0:
                print(f"Unexpected Keys: {unexpected}")
        if not self.cond_stage_trainable and self.cond_stage_model is not None:
            self.cond_stage_model.eval()
            self.cond_stage_model.train = disabled_train
            for param in self.cond_stage_model.parameters():
                param.requires_grad = False
        # else:
        #     assert config != '__is_first_stage__'  # TODO: may not be necessary
        #     assert config != '__is_unconditional__'
        #     # model = instantiate_from_config(config)
        #     model = DenoisingTransformer(cfg=cfg)
        #     self.cond_stage_model = model
        #     sd = torch.load(config, map_location="cpu")
        #     if "state_dict" in list(sd.keys()):
        #         sd = sd["state_dict"]
        #     keys = list(sd.keys())
        #     missing, unexpected = self.cond_stage_model.load_state_dict(sd, strict=False)
        #     print(f"Restored from {config} with {len(missing)} missing and {len(unexpected)} unexpected keys")
        #     if len(missing) > 0:
        #         print(f"Missing Keys: {missing}")
        #     if len(unexpected) > 0:
        #         print(f"Unexpected Keys: {unexpected}")

    def _get_denoise_row_from_list(self, samples, desc='', force_no_decoder_quantization=False):
        denoise_row = []
        for zd in tqdm(samples, desc=desc):
            denoise_row.append(self.decode_first_stage(zd.to(self.device),
                                                            force_not_quantize=force_no_decoder_quantization))
        n_imgs_per_row = len(denoise_row)
        denoise_row = torch.stack(denoise_row)  # n_log_step, n_row, C, H, W
        denoise_grid = rearrange(denoise_row, 'n b c h w -> b n c h w')
        denoise_grid = rearrange(denoise_grid, 'b n c h w -> (b n) c h w')
        denoise_grid = make_grid(denoise_grid, nrow=n_imgs_per_row)
        return denoise_grid

    def get_first_stage_encoding(self, encoder_posterior):
        if isinstance(encoder_posterior, DiagonalGaussianDistribution):
            z = encoder_posterior.sample()  # TODO: what is the role of DiagonalGaussian? this sample needs batch_idx?
        elif isinstance(encoder_posterior, torch.Tensor):
            z = encoder_posterior
        else:
            raise NotImplementedError(f"encoder_posterior of type '{type(encoder_posterior)}' not yet implemented")
        return self.scale_factor * z

    def get_learned_conditioning(self, c):
        if self.cond_stage_forward is None:
            if hasattr(self.cond_stage_model, 'encode') and callable(self.cond_stage_model.encode):
                c = self.cond_stage_model.encode(c)
                if isinstance(c, DiagonalGaussianDistribution):
                    c = c.mode()
            else:
                c = self.cond_stage_model(c)
        else:
            assert hasattr(self.cond_stage_model, self.cond_stage_forward)
            c = getattr(self.cond_stage_model, self.cond_stage_forward)(c)
        return c

    def meshgrid(self, h, w):
        y = torch.arange(0, h).view(h, 1, 1).repeat(1, w, 1)
        x = torch.arange(0, w).view(1, w, 1).repeat(h, 1, 1)

        arr = torch.cat([y, x], dim=-1)
        return arr

    def delta_border(self, h, w):
        """
        :param h: height
        :param w: width
        :return: normalized distance to image border,
         wtith min distance = 0 at border and max dist = 0.5 at image center
        """
        lower_right_corner = torch.tensor([h - 1, w - 1]).view(1, 1, 2)
        arr = self.meshgrid(h, w) / lower_right_corner
        dist_left_up = torch.min(arr, dim=-1, keepdims=True)[0]
        dist_right_down = torch.min(1 - arr, dim=-1, keepdims=True)[0]
        edge_dist = torch.min(torch.cat([dist_left_up, dist_right_down], dim=-1), dim=-1)[0]
        return edge_dist

    def get_weighting(self, h, w, Ly, Lx, device):
        weighting = self.delta_border(h, w)
        weighting = torch.clip(weighting, self.split_input_params["clip_min_weight"],
                               self.split_input_params["clip_max_weight"], )
        weighting = weighting.view(1, h * w, 1).repeat(1, 1, Ly * Lx).to(device)

        if self.split_input_params["tie_braker"]:
            L_weighting = self.delta_border(Ly, Lx)
            L_weighting = torch.clip(L_weighting,
                                     self.split_input_params["clip_min_tie_weight"],
                                     self.split_input_params["clip_max_tie_weight"])

            L_weighting = L_weighting.view(1, 1, Ly * Lx).to(device)
            weighting = weighting * L_weighting
        return weighting

    def get_fold_unfold(self, x, kernel_size, stride, uf=1, df=1):  # todo load once not every time, shorten code
        """
        :param x: img of size (bs, c, h, w)
        :return: n img crops of size (n, bs, c, kernel_size[0], kernel_size[1])
        """
        bs, nc, h, w = x.shape

        # number of crops in image
        Ly = (h - kernel_size[0]) // stride[0] + 1
        Lx = (w - kernel_size[1]) // stride[1] + 1

        if uf == 1 and df == 1:
            fold_params = dict(kernel_size=kernel_size, dilation=1, padding=0, stride=stride)
            unfold = torch.nn.Unfold(**fold_params)

            fold = torch.nn.Fold(output_size=x.shape[2:], **fold_params)

            weighting = self.get_weighting(kernel_size[0], kernel_size[1], Ly, Lx, x.device).to(x.dtype)
            normalization = fold(weighting).view(1, 1, h, w)  # normalizes the overlap
            weighting = weighting.view((1, 1, kernel_size[0], kernel_size[1], Ly * Lx))

        elif uf > 1 and df == 1:
            fold_params = dict(kernel_size=kernel_size, dilation=1, padding=0, stride=stride)
            unfold = torch.nn.Unfold(**fold_params)

            fold_params2 = dict(kernel_size=(kernel_size[0] * uf, kernel_size[0] * uf),
                                dilation=1, padding=0,
                                stride=(stride[0] * uf, stride[1] * uf))
            fold = torch.nn.Fold(output_size=(x.shape[2] * uf, x.shape[3] * uf), **fold_params2)

            weighting = self.get_weighting(kernel_size[0] * uf, kernel_size[1] * uf, Ly, Lx, x.device).to(x.dtype)
            normalization = fold(weighting).view(1, 1, h * uf, w * uf)  # normalizes the overlap
            weighting = weighting.view((1, 1, kernel_size[0] * uf, kernel_size[1] * uf, Ly * Lx))

        elif df > 1 and uf == 1:
            fold_params = dict(kernel_size=kernel_size, dilation=1, padding=0, stride=stride)
            unfold = torch.nn.Unfold(**fold_params)

            fold_params2 = dict(kernel_size=(kernel_size[0] // df, kernel_size[0] // df),
                                dilation=1, padding=0,
                                stride=(stride[0] // df, stride[1] // df))
            fold = torch.nn.Fold(output_size=(x.shape[2] // df, x.shape[3] // df), **fold_params2)

            weighting = self.get_weighting(kernel_size[0] // df, kernel_size[1] // df, Ly, Lx, x.device).to(x.dtype)
            normalization = fold(weighting).view(1, 1, h // df, w // df)  # normalizes the overlap
            weighting = weighting.view((1, 1, kernel_size[0] // df, kernel_size[1] // df, Ly * Lx))

        else:
            raise NotImplementedError

        return fold, unfold, normalization, weighting

    @torch.no_grad()
    def get_input(self, batch, prompt_graph_batch=None, return_first_stage_outputs=False, force_c_encode=False,
                  cond_key=None, return_original_cond=False):
        batch = super().get_input(batch)
        batch = batch.to(self.device)
        batch.x_0 = batch.x.clone().detach()
        batch.edge_attr_0 = batch.edge_attr.clone().detach()

        input_label = batch.y.clone().detach() if cfg.train.pretrain.input_target else None
        if input_label is not None and cfg.dataset.format == 'PyG-QM9':
            input_label = (input_label - batch.y_mean) / batch.y_std
        batch_z = copy.deepcopy(batch)
        if batch.get("prefix", None) is not None:
            batch_z.prefix = batch.prefix
        batch_z = self.encode_first_stage(batch_z, label=input_label)  # original space stored in x_0, edge_attr_0
        # batch_z = self.get_first_stage_encoding(encoder_posterior)
        if not self.first_stage_trainable:
            batch_z.x = batch_z.x.detach()
            batch_z.edge_attr = batch_z.edge_attr.detach()
            batch_z.graph_attr = batch_z.graph_attr.detach()
        # TODO: (1) notice whether should be detach;
        #  (2) the output format, should concat

        if self.model.conditioning_key is not None:
            if cond_key is None:
                cond_key = self.cond_stage_key
            if cond_key == 'masked_graph':
                batch_masked = copy.deepcopy(batch)
                batch_masked.x = batch.x_masked.clone().detach()  # TODO (done): operate masking in main function
                batch_masked.edge_attr = batch.edge_attr_masked.clone().detach()
                if batch.get("prefix", None) is not None:
                    batch_masked.prefix = batch.prefix
                batch_masked = self.get_learned_conditioning(batch_masked)
                if not self.first_stage_trainable or not self.cond_stage_trainable:
                    batch_masked.x = batch_masked.x.detach()
                    batch_masked.edge_attr = batch_masked.edge_attr.detach()
                    batch_masked.graph_attr = batch_masked.graph_attr.detach()
                xc = (batch.x_masked, batch.edge_attr_masked)
                c = (batch_masked.x, batch_masked.edge_attr, batch_masked.graph_attr)
            elif cond_key == 'unconditional':
                xc = None
                c = None
            elif cond_key == 'pe':  # undone
                pos_node = batch.get('pestat_node', torch.zeros([batch.num_nodes, self.model.diffusion_model.cond_dim], dtype=torch.float, device=batch.x.device))
                pos_edge = batch.get('pestat_edge', torch.zeros([batch.edge_index.shape[1], self.model.diffusion_model.cond_dim], dtype=torch.float, device=batch.x.device))
                pos_graph = batch.get('pestat_graph', torch.zeros([batch.num_graphs, self.model.diffusion_model.cond_dim], dtype=torch.float, device=batch.x.device))
                if not hasattr(batch, 'pestat_node'):
                    logging.info('No pe was found for node')
                if not hasattr(batch, 'pestat_edge'):
                    logging.info('No pe was found for edge')
                xc = (pos_node, pos_edge, pos_graph)
                c = (pos_node, pos_edge, pos_graph)
            elif cond_key == 'prompt_graph':
                assert prompt_graph_batch is not None
                prompt_graph_batch.task_id = batch.get('task_id', None)
                xc = (prompt_graph_batch.x, prompt_graph_batch.edge_attr)
                c = self.get_learned_conditioning(prompt_graph_batch).graph_attr  # TODO: here use graph_attr as prompt
                if not self.first_stage_trainable or not self.cond_stage_trainable:
                    c = c.detach()
            elif cond_key == 'class_label':
                xc = batch.y
                if cfg.dataset.format == 'PyG-QM9':
                    xc = (xc - batch.y_mean) / batch.y_std
                if cfg.dt.get("cond_dim", 1) == cfg.encoder.hid_dim:
                    c = self.cond_stage_model.encode_label(xc)
                elif cfg.dt.get("cond_dim", 1) == 1:
                    c = xc
                else:
                    raise NotImplementedError
                if len(c.shape) == 1:
                    c = c.unsqueeze(1).unsqueeze(2)
                if len(c.shape) == 2:
                    c = c.unsqueeze(1)
                if not self.cond_stage_trainable:
                    c = c.detach()
            elif cond_key in ['prefix', 'multi-modal']:
                xc = batch[cond_key]
                c = self.get_learned_conditioning(xc)
                if not self.cond_stage_trainable:
                    c = c.detach()
            else:
                raise NotImplementedError

        else:
            c = None
            xc = None

        batch.x_start = torch.cat([batch_z.x, batch_z.edge_attr], dim=0)
        batch.graph_start = batch_z.graph_attr.clone().detach()
        batch.c = c
        if return_first_stage_outputs:
            xrec_x, xrec_e, xrec_g = self.decode_first_stage(batch_z)  # TODO: implement decode_first_stage
            batch.x_rec = xrec_x
            batch.edge_attr_rec = xrec_e
            batch.graph_attr_rec = xrec_g
        if return_original_cond:
            batch.xc = xc
        return batch

    @torch.no_grad()
    def decode_first_stage(self, batch_z):
        return self.first_stage_model.decode(batch_z)  # TODO: implement .decode() method for first_stage_model

    @torch.no_grad()
    def encode_first_stage(self, batch_x, label=None, prefix=None):
        if hasattr(self.first_stage_model, 'encode') and callable(self.first_stage_model.encode):
            return self.first_stage_model.encode(batch_x, prefix=prefix, label=label)
        else:
            return self.first_stage_model(batch_x, prefix=prefix, label=label)

    # TODO: use this shared_step in training; the return is loss_value, loss_dict
    def shared_step(self, batch, t=None, prompt_graph_batch=None, task_id=None, **kwargs):
        if task_id is not None:
            batch.task_id = task_id
        batch = self.get_input(batch, prompt_graph_batch=prompt_graph_batch)
        loss = self(batch, t=t)
        return loss

    def training_step(self, batch, prompt_graph_batch=None, task_id=None):
        if self.train_mode == 'sample':
            t = torch.randint(0, self.num_timesteps, (batch.num_graphs,), device=self.device).long()
        elif self.train_mode == 'half-sample':
            t = torch.randint(0, 2 * self.num_timesteps, (batch.num_graphs,), device=self.device).long()
            t[t >= self.num_timesteps] = self.num_timesteps - 1
        else:
            t = torch.ones((batch.num_graphs, ), device=self.device).long() * (self.num_timesteps - 1)
        loss, loss_dict, loss_task, graph_pred, loss_node, loss_edge, loss_graph, loss_encoder = self.shared_step(batch, t=t, prompt_graph_batch=prompt_graph_batch, task_id=task_id)

        self.log_dict(loss_dict, prog_bar=True,
                      logger=True, on_step=True, on_epoch=True)

        self.log("global_step", self.global_step,
                 prog_bar=True, logger=True, on_step=True, on_epoch=False)

        if self.use_scheduler:
            lr = self.optimizers().param_groups[0]['lr']
            self.log('lr_abs', lr, prog_bar=True, logger=True, on_step=True, on_epoch=False)

        return loss, loss_task, graph_pred, loss_node, loss_edge, loss_graph, loss_encoder

    @torch.no_grad()
    def validation_step(self, batch, prompt_graph_batch=None, task_id=None):
        t = torch.ones((batch.num_graphs, ), device=self.device).long() * (self.num_timesteps)
        loss, loss_dict_no_ema, loss_graph, graph_pred = self.shared_step(batch, t=t, prompt_graph_batch=prompt_graph_batch, task_id=task_id)
        # with self.ema_scope():
        #     _, loss_dict_ema = self.shared_step(batch, task_id)
        #     loss_dict_ema = {key + '_ema': loss_dict_ema[key] for key in loss_dict_ema}
        self.log_dict(loss_dict_no_ema, prog_bar=False, logger=True, on_step=False, on_epoch=True)
        # self.log_dict(loss_dict_ema, prog_bar=False, logger=True, on_step=False, on_epoch=True)
        return loss, loss_graph, graph_pred

    def forward(self, batch, t=None, *args, **kwargs):
        if t is None:
            t = torch.randint(0, self.num_timesteps, (batch.num_graphs,), device=self.device).long()
        c = batch.get("c", None)
        # TODO: reconsider the loss
        # x_start = batch.x_start
        if self.model.conditioning_key is not None:
            assert c is not None
        
        # FIX: Ensure required attributes exist for inference compatibility
        if not hasattr(batch, 'batch_idx') or batch.batch_idx is None:
            # Create batch_idx similar to get_input() method
            num_node = batch.get('num_node_per_graph', 
                               torch.tensor([batch.num_nodes // batch.num_graphs] * batch.num_graphs, 
                                          dtype=torch.long, device=batch.x.device))
            # For latent diffusion on graphs, we need indices for both nodes and edges
            batch_idx = torch.cat([batch.batch, num2batch(num_node ** 2)], dim=0)
            batch.batch_idx = batch_idx
            
        # FIX: Ensure x_start and graph_start exist for LatentDiffusion inference
        if not hasattr(batch, 'x_start') or batch.x_start is None:
            # Create x_start and graph_start similar to LatentDiffusion.get_input() method
            import copy
            
            # Store original features for encoder input  
            batch.x_0 = batch.x.clone().detach()
            batch.edge_attr_0 = batch.edge_attr.clone().detach() if hasattr(batch, 'edge_attr') else None
            
            # Create a copy for encoding
            batch_z = copy.deepcopy(batch)
            
            # Apply encoder to get latent representations
            input_label = batch.y.clone().detach() if hasattr(batch, 'y') and cfg.train.pretrain.input_target else None
            batch_z = self.encode_first_stage(batch_z, label=input_label)
            
            # Create x_start and graph_start from encoded features
            batch.x_start = torch.cat([batch_z.x, batch_z.edge_attr], dim=0)
            batch.graph_start = batch_z.graph_attr.clone().detach()
        
        # For inference, return only pred and true (expected by eval_epoch)
        if not self.training:
            # Run p_losses to get all outputs
            loss, loss_dict, loss_task, graph_decode, loss_node, loss_edge, loss_graph, loss_graph_encoder = self.p_losses(batch, c, t, batch.batch_idx, *args, **kwargs)
            # Return only prediction and true values for evaluation
            return graph_decode, batch.y.clone().detach()
        else:
            # For training, return the full p_losses output
            return self.p_losses(batch, c, t, batch.batch_idx, *args, **kwargs)

    def _rescale_annotations(self, bboxes, crop_coordinates):  # TODO: move to dataset
        def rescale_bbox(bbox):
            x0 = clamp((bbox[0] - crop_coordinates[0]) / crop_coordinates[2])
            y0 = clamp((bbox[1] - crop_coordinates[1]) / crop_coordinates[3])
            w = min(bbox[2] / crop_coordinates[2], 1 - x0)
            h = min(bbox[3] / crop_coordinates[3], 1 - y0)
            return x0, y0, w, h

        return [rescale_bbox(b) for b in bboxes]

    def apply_model(self, x_noisy, t, cond, return_ids=False):  # this seems not used

        if isinstance(cond, dict):
            # hybrid case, cond is exptected to be a dict
            pass
        else:
            if not isinstance(cond, list):
                cond = [cond]
            key = 'c_concat' if self.model.conditioning_key == 'concat' else 'c_crossattn'
            cond = {key: cond}

        if hasattr(self, "split_input_params"):
            assert len(cond) == 1  # todo can only deal with one conditioning atm
            assert not return_ids
            ks = self.split_input_params["ks"]  # eg. (128, 128)
            stride = self.split_input_params["stride"]  # eg. (64, 64)

            h, w = x_noisy.shape[-2:]

            fold, unfold, normalization, weighting = self.get_fold_unfold(x_noisy, ks, stride)

            z = unfold(x_noisy)  # (bn, nc * prod(**ks), L)
            # Reshape to img shape
            z = z.view((z.shape[0], -1, ks[0], ks[1], z.shape[-1]))  # (bn, nc, ks[0], ks[1], L )
            z_list = [z[:, :, :, :, i] for i in range(z.shape[-1])]

            if self.cond_stage_key in ["image", "LR_image", "segmentation",
                                       'bbox_img'] and self.model.conditioning_key:  # todo check for completeness
                c_key = next(iter(cond.keys()))  # get key
                c = next(iter(cond.values()))  # get value
                assert (len(c) == 1)  # todo extend to list with more than one elem
                c = c[0]  # get element

                c = unfold(c)
                c = c.view((c.shape[0], -1, ks[0], ks[1], c.shape[-1]))  # (bn, nc, ks[0], ks[1], L )

                cond_list = [{c_key: [c[:, :, :, :, i]]} for i in range(c.shape[-1])]

            elif self.cond_stage_key == 'coordinates_bbox':
                assert 'original_image_size' in self.split_input_params, 'BoudingBoxRescaling is missing original_image_size'

                # assuming padding of unfold is always 0 and its dilation is always 1
                n_patches_per_row = int((w - ks[0]) / stride[0] + 1)
                full_img_h, full_img_w = self.split_input_params['original_image_size']
                # as we are operating on latents, we need the factor from the original image size to the
                # spatial latent size to properly rescale the crops for regenerating the bbox annotations
                num_downs = self.first_stage_model.encoder.num_resolutions - 1
                rescale_latent = 2 ** (num_downs)

                # get top left postions of patches as conforming for the bbbox tokenizer, therefore we
                # need to rescale the tl patch coordinates to be in between (0,1)
                tl_patch_coordinates = [(rescale_latent * stride[0] * (patch_nr % n_patches_per_row) / full_img_w,
                                         rescale_latent * stride[1] * (patch_nr // n_patches_per_row) / full_img_h)
                                        for patch_nr in range(z.shape[-1])]

                # patch_limits are tl_coord, width and height coordinates as (x_tl, y_tl, h, w)
                patch_limits = [(x_tl, y_tl,
                                 rescale_latent * ks[0] / full_img_w,
                                 rescale_latent * ks[1] / full_img_h) for x_tl, y_tl in tl_patch_coordinates]
                # patch_values = [(np.arange(x_tl,min(x_tl+ks, 1.)),np.arange(y_tl,min(y_tl+ks, 1.))) for x_tl, y_tl in tl_patch_coordinates]

                # tokenize crop coordinates for the bounding boxes of the respective patches
                patch_limits_tknzd = [torch.LongTensor(self.bbox_tokenizer._crop_encoder(bbox))[None].to(self.device)
                                      for bbox in patch_limits]  # list of length l with tensors of shape (1, 2)
                print(patch_limits_tknzd[0].shape)
                # cut tknzd crop position from conditioning
                assert isinstance(cond, dict), 'cond must be dict to be fed into model'
                cut_cond = cond['c_crossattn'][0][..., :-2].to(self.device)
                print(cut_cond.shape)

                adapted_cond = torch.stack([torch.cat([cut_cond, p], dim=1) for p in patch_limits_tknzd])
                adapted_cond = rearrange(adapted_cond, 'l b n -> (l b) n')
                print(adapted_cond.shape)
                adapted_cond = self.get_learned_conditioning(adapted_cond)
                print(adapted_cond.shape)
                adapted_cond = rearrange(adapted_cond, '(l b) n d -> l b n d', l=z.shape[-1])
                print(adapted_cond.shape)

                cond_list = [{'c_crossattn': [e]} for e in adapted_cond]

            else:
                cond_list = [cond for i in range(z.shape[-1])]  # Todo make this more efficient

            # apply model by loop over crops
            output_list = [self.model(z_list[i], t, **cond_list[i]) for i in range(z.shape[-1])]
            assert not isinstance(output_list[0],
                                  tuple)  # todo cant deal with multiple model outputs check this never happens

            o = torch.stack(output_list, axis=-1)
            o = o * weighting
            # Reverse reshape to img shape
            o = o.view((o.shape[0], -1, o.shape[-1]))  # (bn, nc * ks[0] * ks[1], L)
            # stitch crops together
            x_recon = fold(o) / normalization

        else:
            x_recon = self.model(x_noisy, t, **cond)

        if isinstance(x_recon, tuple) and not return_ids:
            return x_recon[0]
        else:
            return x_recon

    def _predict_eps_from_xstart(self, x_t, t, pred_xstart, batch_idx):
        return (extract_into_sparse_tensor(self.sqrt_recip_alphas_cumprod, t, batch_idx) * x_t - pred_xstart) / \
               extract_into_sparse_tensor(self.sqrt_recipm1_alphas_cumprod, t, batch_idx)

    def _prior_bpd(self, x_start, batch_idx):
        """
        Get the prior KL term for the variational lower-bound, measured in
        bits-per-dim.
        This term can't be optimized, as it only depends on the encoder.
        :param x_start: the [N x C x ...] tensor of inputs.
        :return: a batch of [N] KL values (in bits), one per batch element.
        """
        batch_size = x_start.shape[0]
        t = torch.tensor([self.num_timesteps - 1] * batch_size, device=x_start.device)
        qt_mean, _, qt_log_variance = self.q_mean_variance(x_start, t, batch_idx)
        kl_prior = normal_kl(mean1=qt_mean, logvar1=qt_log_variance, mean2=0.0, logvar2=0.0)
        return mean_flat(kl_prior) / np.log(2.0)

    # TODO: reconsider how to construct the loss; also note for different levels/task types
    def p_losses(self, batch, cond, t, batch_idx, noise=None):
        x_start = batch.x_start.clone().detach()
        graph_attr_label = batch.graph_start.clone().detach()
        noise = default(noise, lambda: torch.randn_like(x_start))
        # logging.info(x_start.shape)
        if self.force_undirected:
            noise_symmetrized_edge = symmetrize(batch.edge_index, batch.batch, noise[batch.num_nodes:, :])
            noise[batch.num_nodes:, :] = noise_symmetrized_edge
        x_noisy = self.q_sample(x_start=x_start, t=t, noise=noise, batch_idx=batch_idx)
        batch_noisy = copy.deepcopy(batch)
        batch_noisy.x = x_noisy[:batch.num_nodes, :]
        batch_noisy.edge_attr = x_noisy[batch.num_nodes:, :]
        batch_output = self.model(batch_noisy, t, cond)
        model_output = torch.cat([batch_output.x, batch_output.edge_attr], dim=0)
        node_decode, edge_decode, graph_decode = self.decode_first_stage(batch_output)
        if cfg.dataset.format == 'PyG-QM9':
            graph_decode = graph_decode * batch.get('y_std', 1.) + batch.get('y_mean', 0.)
        # logging.info(model_output.shape)

        loss_task, graph_decode = compute_loss(graph_decode, batch.y.clone().detach())

        if cfg.train.mode in ['qm9_unconditional', 'qm9_conditional']:
            generated_mol = []
            accumulated_node, accumulated_edge = 0, 0
            for i in range(batch.num_graphs):
                generated_mol.append((torch.argmax(node_decode[accumulated_node: accumulated_node + batch.num_node_per_graph[i]], dim=1, keepdim=False),
                                      torch.argmax(edge_decode[accumulated_edge: accumulated_edge + batch.num_node_per_graph[i] ** 2], dim=1, keepdim=False).reshape(batch.num_node_per_graph[i], batch.num_node_per_graph[i]),
                                      graph_decode[i].unsqueeze(0)))
                accumulated_node += batch.num_node_per_graph[i]
                accumulated_edge += batch.num_node_per_graph[i] ** 2
            graph_decode = generated_mol

        elif cfg.train.mode in ['generic_generation']:
            generic_graphs = []
            accumulated_node, accumulated_edge = 0, 0
            for i in range(batch.num_graphs):
                adj = torch.argmax(edge_decode[accumulated_edge: accumulated_edge + batch.num_node_per_graph[i] ** 2], dim=1, keepdim=False)\
                      .reshape(batch.num_node_per_graph[i], batch.num_node_per_graph[i]).detach().cpu().numpy()
                G = nx.from_numpy_array(adj)
                G.remove_edges_from(nx.selfloop_edges(G))
                G.remove_nodes_from(list(nx.isolates(G)))
                if G.number_of_nodes() < 1:
                    G.add_node(1)
                generic_graphs.append(G)

                accumulated_node += batch.num_node_per_graph[i]
                accumulated_edge += batch.num_node_per_graph[i] ** 2
            graph_decode = generic_graphs

        loss_dict = {}
        prefix = 'train' if self.training else 'val'

        if self.parameterization == "x0":
            target = x_start
        elif self.parameterization == "eps":
            target = noise
        else:
            raise NotImplementedError()

        # graph_criterion = nn.MSELoss()
        # loss_task = graph_criterion(graph_decode, batch.y)
        # encoder_criterion = nn.L1Loss() if cfg.model.loss_fun == 'l1' else nn.CrossEntropyLoss()
        # loss_graph = torch.nn.functional.mse_loss(batch_output.graph_attr, graph_attr_label).mean()
        # encoder_pred = self.first_stage_model.decode_graph(graph_attr_label).flatten()
        # if cfg.dataset.format == 'PyG-QM9':
        #     encoder_pred = encoder_pred * batch.get('y_std', 1.) + batch.get('y_mean', 0.)
        # loss_graph_encoder, _ = compute_loss(encoder_pred, batch.y.clone().detach())
        loss_graph_encoder = torch.tensor(0., device=self.device, requires_grad=False)
        # TODO: complete loss_graph_encoder for class GraphTransformerDecoder
        # print(loss_graph_encoder)

        loss_simple = self.get_loss(model_output, target, mean=False).mean([1])
        loss_graph = self.get_loss(batch_output.graph_attr, graph_attr_label, mean=False).mean([1])
        loss_dict.update({f'{prefix}/loss_simple': loss_simple.mean()})
        loss_dict.update({f'{prefix}/loss_graph': loss_graph.mean()})

        if (t >= self.num_timesteps).any():
            t = t - 1
        logvar_t = self.logvar[t].to(self.device)
        logvar_t = logvar_t[batch_idx]
        loss = loss_simple / torch.exp(logvar_t) + logvar_t
        # loss = loss_simple / torch.exp(self.logvar) + self.logvar
        if self.learn_logvar:
            loss_dict.update({f'{prefix}/loss_gamma': loss.mean()})
            loss_dict.update({'logvar': self.logvar.data.mean()})

        loss = self.l_simple_weight * loss
        loss_node = loss[:batch.num_nodes].mean() * self.node_factor
        loss_edge = loss[batch.num_nodes:].mean() * self.edge_factor
        loss_graph = loss_graph.mean() * self.graph_factor
        loss = loss_node + loss_edge + loss_graph

        loss_vlb = self.get_loss(model_output, target, mean=False).mean(dim=1)
        loss_vlb = self.lvlb_weights[t][batch_idx] * loss_vlb
        loss_vlb = loss_vlb[:batch.num_nodes].mean() * self.node_factor + loss_vlb[batch.num_nodes:].mean() * self.edge_factor \
            + (self.get_loss(batch_output.graph_attr, graph_attr_label, mean=False).mean(dim=1) * self.lvlb_weights[t]).mean() * self.graph_factor
        loss_dict.update({f'{prefix}/loss_vlb': loss_vlb})
        loss += (self.original_elbo_weight * loss_vlb)
        loss_dict.update({f'{prefix}/loss': loss})
        loss_dict.update({f'{prefix}/loss_task': loss_task})

        # TODO: these lines do not apply for generic graphs because the decoding method is different
        if hasattr(self.first_stage_model, 'decode_recon') and callable(self.first_stage_model.decode_recon) and self.recon_factor > 0:
            node_recon, edge_recon = self.first_stage_model.decode_recon(batch_output)
            criterion_node = nn.CrossEntropyLoss()
            criterion_edge = nn.CrossEntropyLoss()
            loss_structure_recon = criterion_node(node_recon, batch.x_0.flatten()) * self.node_factor \
                                   + criterion_edge(edge_recon, batch.edge_attr_0.flatten()) * self.edge_factor
            loss += loss_structure_recon * self.recon_factor

        return loss, loss_dict, loss_task, graph_decode, loss_node, loss_edge, loss_graph, loss_graph_encoder

    def p_mean_variance(self, batch_x, c, t, batch_idx, clip_denoised: bool, return_codebook_ids=False, quantize_denoised=False,
                        return_x0=False, score_corrector=None, corrector_kwargs=None):
        t_in = t
        x = torch.cat([batch_x.x.clone(), batch_x.edge_attr.clone()], dim=0)
        batch_model_out = self.model(batch_x, t_in, c)

        if score_corrector is not None:
            assert self.parameterization == "eps"
            batch_model_out = score_corrector.modify_score(self, batch_model_out, batch_x, t, c, **corrector_kwargs)

        if return_codebook_ids:
            batch_model_out, logits = batch_model_out

        if self.parameterization == "eps":
            x_recon = self.predict_start_from_noise(x, t=t, noise=torch.cat([batch_model_out.x, batch_model_out.edge_attr], dim=0), batch_idx=batch_idx) # TODO: not completed
        elif self.parameterization == "x0":
            x_recon = torch.cat([batch_model_out.x, batch_model_out.edge_attr], dim=0)
        else:
            raise NotImplementedError()

        if clip_denoised:
            x_recon.clamp_(-1., 1.)
        if quantize_denoised:
            x_recon, _, [_, _, indices] = self.first_stage_model.quantize(x_recon)
        model_mean, posterior_variance, posterior_log_variance = self.q_posterior(x_start=x_recon, x_t=x, t=t, batch_idx=batch_idx)
        if return_codebook_ids:
            return model_mean, posterior_variance, posterior_log_variance, logits
        elif return_x0:
            return model_mean, posterior_variance, posterior_log_variance, x_recon
        else:
            return model_mean, posterior_variance, posterior_log_variance

    @torch.no_grad()
    def p_sample(self, batch_x, c, t, batch_idx, clip_denoised=False, repeat_noise=False,
                 return_codebook_ids=False, quantize_denoised=False, return_x0=False,
                 temperature=1., noise_dropout=0., score_corrector=None, corrector_kwargs=None):
        # b, *_, device = *x.shape, x.device
        device = batch_x.x.device
        b = batch_idx.shape[0]
        outputs = self.p_mean_variance(batch_x=batch_x, c=c, t=t, batch_idx=batch_idx, clip_denoised=clip_denoised,
                                       return_codebook_ids=return_codebook_ids,
                                       quantize_denoised=quantize_denoised,
                                       return_x0=return_x0,
                                       score_corrector=score_corrector, corrector_kwargs=corrector_kwargs)
        if return_codebook_ids:
            raise DeprecationWarning("Support dropped.")
            model_mean, _, model_log_variance, logits = outputs
        elif return_x0:
            model_mean, _, model_log_variance, x0 = outputs
        else:
            model_mean, _, model_log_variance = outputs

        noise = noise_like(model_mean.shape, device, repeat_noise) * temperature
        if self.force_undirected:
            symmetrized = symmetrize(batch_x.edge_index, batch_x.batch, noise[batch_x.num_nodes:])
            noise[batch_x.num_nodes:] = symmetrized
        if noise_dropout > 0.:
            noise = torch.nn.functional.dropout(noise, p=noise_dropout)
        # no noise when t == 0
        # nonzero_mask = (1 - (t == 0).float()).reshape(b, *((1,) * (len(x.shape) - 1)))
        nonzero_mask = (1 - (t == 0).float())[batch_idx].reshape(-1, 1)

        p_sampled_x = model_mean + nonzero_mask * (0.5 * model_log_variance).exp() * noise
        batch_x.x = p_sampled_x[:batch_x.num_nodes]
        batch_x.edge_attr = p_sampled_x[batch_x.num_nodes:]

        if return_codebook_ids:
            return batch_x, logits.argmax(dim=1)
        if return_x0:
            return batch_x, x0
        else:
            return batch_x

    # this function is not used
    @torch.no_grad()
    def progressive_denoising(self, batch, cond, shape, batch_idx, verbose=True, callback=None, quantize_denoised=False,
                              img_callback=None, mask=None, x0=None, temperature=1., noise_dropout=0.,
                              score_corrector=None, corrector_kwargs=None, batch_size=None, x_T=None, start_T=None,
                              log_every_t=None):
        if not log_every_t:
            log_every_t = self.log_every_t
        timesteps = self.num_timesteps
        if batch_size is not None:
            b = batch_size if batch_size is not None else int(torch.max(batch_idx)) + 1
            # shape = [batch_size] + list(shape)
        else:
            b = batch_size = int(torch.max(batch_idx)) + 1
        if x_T is None:
            img = torch.randn(shape, device=self.device)
        else:
            img = x_T

        batch.x = img[: batch.num_nodes]
        batch.edge_attr = img[batch.num_nodes:]

        intermediates = []
        if cond is not None:
            if isinstance(cond, dict):
                cond = {key: cond[key][:batch_size] if not isinstance(cond[key], list) else
                list(map(lambda x: x[:batch_size], cond[key])) for key in cond}
            else:
                cond = [c[:batch_size] for c in cond] if isinstance(cond, list) else cond[:batch_size]

        if start_T is not None:
            timesteps = min(timesteps, start_T)
        iterator = tqdm(reversed(range(0, timesteps)), desc='Progressive Generation',
                        total=timesteps) if verbose else reversed(
            range(0, timesteps))
        if type(temperature) == float:
            temperature = [temperature] * timesteps

        for i in iterator:
            ts = torch.full((b,), i, device=self.device, dtype=torch.long)
            if self.shorten_cond_schedule:
                assert self.model.conditioning_key != 'hybrid'
                tc = self.cond_ids[ts].to(cond.device)
                cond = self.q_sample(x_start=cond, t=tc, noise=torch.randn_like(cond), batch_idx=None)

            batch, x0_partial = self.p_sample(batch, cond, ts, batch_idx=batch_idx,
                                            clip_denoised=self.clip_denoised,
                                            quantize_denoised=quantize_denoised, return_x0=True,
                                            temperature=temperature[i], noise_dropout=noise_dropout,
                                            score_corrector=score_corrector, corrector_kwargs=corrector_kwargs)
            img = torch.cat([batch.x, batch.edge_attr], dim=0)
            if mask is not None:
                assert x0 is not None
                img_orig = self.q_sample(x0, ts, batch_idx=batch_idx)
                img = img_orig * mask + (1. - mask) * img
                batch.x = img[: batch.num_nodes]
                batch.edge_attr = img[batch.num_nodes:]

            if i % log_every_t == 0 or i == timesteps - 1:
                intermediates.append(x0_partial)
            if callback: callback(i)
            if img_callback: img_callback(img, i)
        return batch, intermediates

    @torch.no_grad()
    def p_sample_loop(self, batch, cond, shape, batch_idx, return_intermediates=False,
                      x_T=None, verbose=True, callback=None, timesteps=None, quantize_denoised=False,
                      mask=None, x0=None, img_callback=None, start_T=None,
                      log_every_t=None):

        if not log_every_t:
            log_every_t = self.log_every_t
        device = self.betas.device
        b = int(torch.max(batch_idx)) + 1
        if x_T is None:
            img = torch.randn(shape, device=device, dtype=torch.float)
        else:
            img = x_T

        if self.force_undirected:
            symmetrized = symmetrize(batch.edge_index, batch.batch, img[batch.num_nodes:])
            img[batch.num_nodes:] = symmetrized
        batch.x = img[: batch.num_nodes]
        batch.edge_attr = img[batch.num_nodes:]

        intermediates = [img]
        if timesteps is None:
            timesteps = self.num_timesteps

        if start_T is not None:
            timesteps = min(timesteps, start_T)
        iterator = tqdm(reversed(range(0, timesteps)), desc='Sampling t', total=timesteps) if verbose else reversed(
            range(0, timesteps))

        if mask is not None:
            assert x0 is not None
            # assert x0.shape[2:3] == mask.shape[2:3]  # spatial size has to match

        # batch_idx = num2batch(shape + shape ** 2)
        # batch_idx = torch.cat([num2batch(shape), num2batch(shape ** 2)], dim=0)

        for i in iterator:
            ts = torch.full((b,), i, device=device, dtype=torch.long)
            if self.shorten_cond_schedule:
                assert self.model.conditioning_key != 'hybrid'
                tc = self.cond_ids[ts].to(cond.device)
                cond = self.q_sample(x_start=cond, t=tc, noise=torch.randn_like(cond), batch_idx=None)

            batch = self.p_sample(batch, cond, ts, batch_idx,
                                clip_denoised=self.clip_denoised,
                                quantize_denoised=quantize_denoised)
            # TODO: implement case where there is mask
            img = torch.cat([batch.x, batch.edge_attr], dim=0)
            if mask is not None:
                img_orig = self.q_sample(x0, ts, batch_idx=batch_idx)
                img = img_orig * mask + (1. - mask) * img
                batch.x = img[: batch.num_nodes]
                batch.edge_attr = img[batch.num_nodes:]

            if i % log_every_t == 0 or i == timesteps - 1:
                intermediates.append(img)
            if callback: callback(i)
            if img_callback: img_callback(img, i)

        if return_intermediates:
            return batch, intermediates
        return batch

    @torch.no_grad()
    def sample(self, batch, cond, batch_size=16, batch_idx=None, return_intermediates=False, x_T=None,
               verbose=True, timesteps=None, quantize_denoised=False,
               mask=None, x0=None, shape=None,**kwargs):
        if shape is None:
            shape = (batch_idx.shape[0], self.hid_dim)
        # TODO: check if this part is necessary for multiple conditions
        # if cond is not None:
        #     if isinstance(cond, dict):
        #         cond = {key: cond[key][:batch_size] if not isinstance(cond[key], list) else
        #         list(map(lambda x: x[:batch_size], cond[key])) for key in cond}
        #     else:
        #         cond = [c[:batch_size] for c in cond] if isinstance(cond, list) else cond[:batch_size]  # TODO: check whether this obtain correct cond
        return self.p_sample_loop(batch,
                                  cond,
                                  shape,
                                  batch_idx,
                                  return_intermediates=return_intermediates, x_T=x_T,
                                  verbose=verbose, timesteps=timesteps, quantize_denoised=quantize_denoised,
                                  mask=mask, x0=x0)

    @torch.no_grad()
    def sample_log(self, batch, cond, batch_size, batch_idx, ddim, ddim_steps, eta, use_ddpm_steps, **kwargs):

        if ddim:  # TODO: further implement DDIM
            ddim_sampler = DDIMSampler(self)
            shape = (batch_idx.shape[0], self.hid_dim)
            samples = ddim_sampler.sample(batch, ddim_steps, batch_size,
                                                        shape, cond, verbose=False, eta=eta, return_intermediates=False, **kwargs)

        else:
            samples = self.sample(batch=batch, cond=cond, batch_size=batch_size, batch_idx=batch_idx,
                                                 return_intermediates=False, **kwargs)

        return samples


    @torch.no_grad()
    def inference(self, batch, sample=True, ddim_steps=None, ddim_eta=0., use_ddpm_steps=False, return_keys=None,
                   quantize_denoised=True, inpaint=True, plot_denoise_rows=False, plot_progressive_rows=True,
                   plot_diffusion_rows=True, visualize=False, **kwargs):

        # TODO: implement DDIM related codes
        use_ddim = ddim_steps is not None

        # log = dict()
        N = batch.num_graphs
        batch = self.get_input(batch,  # self.first_stage_key,
                               return_first_stage_outputs=True,
                               force_c_encode=True,
                               return_original_cond=True)
        z, c, x, xrec, xc = (batch.x_start, batch.graph_start), batch.get('c', None), (batch.x_0, batch.edge_attr_0), (batch.x_rec, batch.edge_attr_rec, batch.graph_attr_rec), batch.get('xc', None)
        # TODO: change the output format of above get_input function

        # n_row = min(batch.num_graphs, n_row)
        # num_node = batch.num_node_per_graph
        batch_idx = batch.batch_idx

        samples = self.sample_log(batch=batch, cond=c, batch_size=N, batch_idx=batch_idx, ddim=use_ddim,
                                                 ddim_steps=ddim_steps, eta=ddim_eta, use_ddpm_steps=use_ddpm_steps)
        # samples, z_denoise_row = self.sample(cond=c, batch_size=N, return_intermediates=True)
        if visualize:
            pass
            # visualization is in the main training file
        node_decode, edge_decode, graph_decode = self.decode_first_stage(samples)
        if cfg.dataset.format == 'PyG-QM9':
            graph_decode = graph_decode * batch.get('y_std', 1.) + batch.get('y_mean', 0.)
        loss_graph, graph_decode = compute_loss(graph_decode, batch.y.clone().detach())
        # logging.info(graph_decode)

        if cfg.train.mode in ['qm9_unconditional', 'qm9_conditional']:
            generated_mol = []
            accumulated_node, accumulated_edge = 0, 0
            for i in range(batch.num_graphs):
                generated_mol.append((torch.argmax(node_decode[accumulated_node: accumulated_node + batch.num_node_per_graph[i]], dim=1, keepdim=False),
                                      torch.argmax(edge_decode[accumulated_edge: accumulated_edge + batch.num_node_per_graph[i] ** 2], dim=1, keepdim=False).reshape(batch.num_node_per_graph[i], batch.num_node_per_graph[i]),
                                      graph_decode[i].unsqueeze(0)))
                accumulated_node += batch.num_node_per_graph[i]
                accumulated_edge += batch.num_node_per_graph[i] ** 2
            graph_decode = generated_mol

        elif cfg.train.mode in ['generic_generation']:
            generic_graphs = []
            accumulated_node, accumulated_edge = 0, 0
            for i in range(batch.num_graphs):
                adj = torch.argmax(edge_decode[accumulated_edge: accumulated_edge + batch.num_node_per_graph[i] ** 2], dim=1, keepdim=False)\
                      .reshape(batch.num_node_per_graph[i], batch.num_node_per_graph[i]).detach().cpu().numpy()
                G = nx.from_numpy_array(adj)
                G.remove_edges_from(nx.selfloop_edges(G))
                G.remove_nodes_from(list(nx.isolates(G)))
                if G.number_of_nodes() < 1:
                    G.add_node(1)
                generic_graphs.append(G)

                accumulated_node += batch.num_node_per_graph[i]
                accumulated_edge += batch.num_node_per_graph[i] ** 2
            graph_decode = generic_graphs

        return loss_graph, graph_decode


    def configure_optimizers(self):
        lr = self.learning_rate
        params = list(self.model.parameters())
        if self.cond_stage_trainable:
            print(f"{self.__class__.__name__}: Also optimizing conditioner params!")
            params = params + list(self.cond_stage_model.parameters())
        if self.learn_logvar:
            print('Diffusion model optimizing logvar')
            params.append(self.logvar)
        opt = torch.optim.AdamW(params, lr=lr)
        if self.use_scheduler:
            assert 'target' in self.scheduler_config
            scheduler = instantiate_from_config(self.scheduler_config)

            print("Setting up LambdaLR scheduler...")
            scheduler = [
                {
                    'scheduler': LambdaLR(opt, lr_lambda=scheduler.schedule),
                    'interval': 'step',
                    'frequency': 1
                }]
            return [opt], scheduler
        return opt

    @torch.no_grad()
    def to_rgb(self, x):
        x = x.float()
        if not hasattr(self, "colorize"):
            self.colorize = torch.randn(3, x.shape[1], 1, 1).to(x)
        x = nn.functional.conv2d(x, weight=self.colorize)
        x = 2. * (x - x.min()) / (x.max() - x.min()) - 1.
        return x


class DiffusionWrapper(pl.LightningModule):
    def __init__(self, diff_model_config, conditioning_key):
        super().__init__()
        # self.diffusion_model = instantiate_from_config(diff_model_config)
        self.diffusion_model = DenoisingTransformer(cfg)
        self.conditioning_key = conditioning_key
        assert self.conditioning_key in [None, 'concat', 'crossattn', 'hybrid', 'adm']

    # TODO: haven't implement other conditioning_key forward, including in get_batch()
    def forward(self, x, t, c_crossattn=None, c_concat=None):  # originally c_crossattn and c_concat are list
        if self.conditioning_key is None:
            out = self.diffusion_model(x, t)
        elif self.conditioning_key == 'concat':
            xc = torch.cat([x] + c_concat, dim=1)
            out = self.diffusion_model(xc, t)
        elif self.conditioning_key == 'crossattn':
            # cc = torch.cat(c_crossattn, 1)
            out = self.diffusion_model(x, t, c_crossattn)
        elif self.conditioning_key == 'hybrid':
            xc = torch.cat([x] + c_concat, dim=1)
            cc = torch.cat(c_crossattn, 1)
            out = self.diffusion_model(xc, t, context=cc)
        elif self.conditioning_key == 'adm':
            cc = c_crossattn[0]
            out = self.diffusion_model(x, t, y=cc)
        else:
            raise NotImplementedError()

        return out


class Layout2ImgDiffusion(LatentDiffusion):
    # TODO: move all layout-specific hacks to this class
    def __init__(self, cond_stage_key, *args, **kwargs):
        assert cond_stage_key == 'coordinates_bbox', 'Layout2ImgDiffusion only for cond_stage_key="coordinates_bbox"'
        super().__init__(cond_stage_key=cond_stage_key, *args, **kwargs)

    def log_images(self, batch, N=8, *args, **kwargs):
        logs = super().log_images(batch=batch, N=N, *args, **kwargs)

        key = 'train' if self.training else 'validation'
        dset = self.trainer.datamodule.datasets[key]
        mapper = dset.conditional_builders[self.cond_stage_key]

        bbox_imgs = []
        map_fn = lambda catno: dset.get_textual_label(dset.get_category_id(catno))
        for tknzd_bbox in batch[self.cond_stage_key][:N]:
            bboximg = mapper.plot(tknzd_bbox.detach().cpu(), map_fn, (256, 256))
            bbox_imgs.append(bboximg)

        cond_img = torch.stack(bbox_imgs, dim=0)
        logs['bbox_image'] = cond_img
        return logs
