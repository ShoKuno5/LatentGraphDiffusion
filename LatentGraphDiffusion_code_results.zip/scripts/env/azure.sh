#!/bin/bash
# Azure VM environment defaults

# Allow overrides from caller; set sensible defaults otherwise
export ROOT=${ROOT:-/home/azureuser}
export CODE=${CODE:-$ROOT/LatentGraphDiffusion}
export IMG=${IMG:-$CODE/lgd.sif}
export DATA=${DATA:-$CODE/data}
export RUNS=${RUNS:-$CODE/runs}
export RESULTS=${RESULTS:-$RUNS}

# Distributed / networking
export MASTER_ADDR=${MASTER_ADDR:-127.0.0.1}
export MASTER_PORT=${MASTER_PORT:-29500}
export NCCL_IB_DISABLE=${NCCL_IB_DISABLE:-1}
export NCCL_SOCKET_IFNAME=${NCCL_SOCKET_IFNAME:-eth0}
export GLOO_SOCKET_IFNAME=${GLOO_SOCKET_IFNAME:-eth0}
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-8}

# WandB defaults (expect API key via env or .wandbrc)
export WANDB_MODE=${WANDB_MODE:-online}
export WANDB_PROJECT=${WANDB_PROJECT:-latentgraphdiffusion}

# Helper echo (only if not silenced)
if [ -z "${LGD_ENV_SILENT:-}" ]; then
  echo "[azure] ROOT=$ROOT"
  echo "[azure] CODE=$CODE"
  echo "[azure] DATA=$DATA"
  echo "[azure] RUNS=$RUNS"
  echo "[azure] RESULTS=$RESULTS (unified with RUNS)"
fi
