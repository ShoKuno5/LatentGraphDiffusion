#!/bin/bash
# Wisteria (gp15) environment defaults

# Allow overrides from caller; set sensible defaults otherwise
export ROOT=${ROOT:-/work/gp15/q25030}
export CODE=${CODE:-$ROOT/LatentGraphDiffusion}
export IMG=${IMG:-$CODE/lgd.sif}
export DATA=${DATA:-$CODE/data}
export RUNS=${RUNS:-$CODE/runs}
export RESULTS=${RESULTS:-$RUNS}

# Distributed / threading
export MASTER_ADDR=${MASTER_ADDR:-127.0.0.1}
export MASTER_PORT=${MASTER_PORT:-29500}
export NCCL_IB_DISABLE=${NCCL_IB_DISABLE:-1}
export NCCL_SOCKET_IFNAME=${NCCL_SOCKET_IFNAME:-ib0,eth0}
export GLOO_SOCKET_IFNAME=${GLOO_SOCKET_IFNAME:-ib0,eth0}
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-8}

# WandB defaults
export WANDB_MODE=${WANDB_MODE:-online}  # options: online, offline, disabled
export WANDB_PROJECT=${WANDB_PROJECT:-LatentGraphDiffusion-ZINC-Flow}

# Helper echo (only if not silenced)
if [ -z "${LGD_ENV_SILENT:-}" ]; then
  echo "[wisteria] ROOT=$ROOT"
  echo "[wisteria] CODE=$CODE"
  echo "[wisteria] DATA=$DATA"
  echo "[wisteria] RUNS=$RUNS"
  echo "[wisteria] RESULTS=$RESULTS (unified with RUNS)"
fi
