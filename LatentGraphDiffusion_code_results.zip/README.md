pjsub -x CONFIG=cfg/zinc-flow_baseline.yaml -x CHECKPOINT=runs/zinc_encoder_20250930_004610/my_zinc-encoder_baseline/0/ckpt/399.ckpt -x MAX_EPOCH=200 scripts/zinc_trainer_diffusion_flow.sh
