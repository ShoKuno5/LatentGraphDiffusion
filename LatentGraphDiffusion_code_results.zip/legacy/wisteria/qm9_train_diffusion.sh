#!/bin/bash
# Legacy wrapper: moved from experiments/wisteria/
#PJM -L rscgrp=regular-a
#PJM -L node=1
#PJM -L elapse=72:00:00
#PJM -g gp15
#PJM -L jobenv=singularity
#PJM -j
#PJM -N qm9_train_diffusion
#PJM -o qm9_train_diffusion_%j.out
#PJM -e qm9_train_diffusion_%j.err

source /etc/profile.d/modules.sh
module load singularity/3.7.3
module load cuda/12.6

# -------- host-side paths (via env file) --------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_ROOT/ops/env/wisteria.sh"

# -------- job parameters --------
# Prefer environment variables (set via pjsub -x), fallback to positional args
# QM9 target property - options: mu, alpha, e_HOMO, e_LUMO, delta_e, cv
TARGET_PROPERTY="${TARGET_PROPERTY:-${1:-mu}}"  # Default to mu (dipole moment)
ENCODER_CHECKPOINT="${ENCODER_CHECKPOINT:-${2:-auto}}"  # e.g., pjsub -x ENCODER_CHECKPOINT=/path/to/ckpt
CONFIG="${CONFIG:-cfg/QM9-diffusion_ddpm_regression_${TARGET_PROPERTY}.yaml}"
REPEAT="${REPEAT:-3}"
MAX_EPOCH="${MAX_EPOCH:-50}"

# -------- experiment tag ---------
EXP="qm9_${TARGET_PROPERTY}_diffusion_$(date +%Y%m%d_%H%M%S)"
EXP_DIR=$RUNS/$EXP
mkdir -p "$DATA" "$EXP_DIR"
echo "Directory created: $EXP_DIR $DATA"

# -------- env / NCCL / PyTorch --------
export WANDB_NAME="qm9_${TARGET_PROPERTY}_diffusion_${EXP}"

echo "Starting QM9 Diffusion Training Job"
echo "Target Property: $TARGET_PROPERTY"
echo "Config: $CONFIG"
echo "Max Epochs: $MAX_EPOCH"
echo "Repeats: $REPEAT"
echo "Encoder Checkpoint: $ENCODER_CHECKPOINT"
echo "Experiment: $EXP"
echo "Time started: $(date)"

# -------- singularity + LGD commands --------
singularity exec --nv \
  -B "$CODE":/workspace \
  -B "$RUNS":/workspace/runs \
  -B "$DATA":/workspace/data \
  "$IMG" \
  bash -c "
    cd /workspace;
    export PYTHONPATH=/workspace:\$PYTHONPATH;
    export PYTHONUNBUFFERED=1;
    
    # Create experiment directory
    mkdir -p /workspace/runs/$EXP;
    
    echo 'Environment check...';
    python -c 'import torch; print(f\"PyTorch version: {torch.__version__}\"); print(f\"CUDA available: {torch.cuda.is_available()}\"); print(f\"CUDA device count: {torch.cuda.device_count()}\")';
    python -c 'import torch_geometric; print(f\"PyG version: {torch_geometric.__version__}\")';
    
    /workspace/ops/runners/run_qm9_train_diffusion.sh \
      --target \"$TARGET_PROPERTY\" \
      --checkpoint \"$ENCODER_CHECKPOINT\" \
      --repeat \"$REPEAT\" \
      --max-epoch \"$MAX_EPOCH\" \
      --out-dir \"/workspace/runs/$EXP\" \
      --wandb-name \"qm9_${TARGET_PROPERTY}_diffusion_${EXP}\";
    
    # Check training results
    echo 'Training completed. Checking results...';
    find /workspace/runs/$EXP -name '*.ckpt' -exec ls -la {} \;
    
    # Log completion time
    echo \"Training completed at: \$(date)\";
    echo \"Results saved in: /workspace/runs/$EXP\";
    echo \"Used encoder checkpoint: \$CHECKPOINT_PATH\";
  "

echo "Job completed at: $(date)"
echo "Results saved in: $EXP_DIR"

# Create job completion marker
touch "$EXP_DIR/job_completed.txt"
{
  echo "Job completed successfully at $(date)";
  echo "Target property: $TARGET_PROPERTY";
  echo "Used encoder checkpoint: $ENCODER_CHECKPOINT";
  echo "Config: cfg/QM9-diffusion_ddpm_regression_${TARGET_PROPERTY}.yaml";
  echo "Repeat: $REPEAT, Max Epoch: $MAX_EPOCH";
} > "$EXP_DIR/job_completed.txt"
